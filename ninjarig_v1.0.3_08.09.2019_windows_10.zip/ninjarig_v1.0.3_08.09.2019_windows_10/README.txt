ONLY DO THIS IF THE MINER CRASHES OR GIVES AN ERROR RUNNING CUDA/OPENCL KERNELS

Please run the registry file tdr_delay.reg
It is needed to make windows not kill the graphic driver when it becomes unresponsive because of hashing computation.
Without this registry key there are big chances that the miner will not work on GPU.
This is not needed if you only want to run it on CPU.
After adding the registry key, you need to reboot computer to take effect.
Thank you and happy mining!